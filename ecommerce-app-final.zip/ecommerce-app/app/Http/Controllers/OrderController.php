<?php

namespace App\Http\Controllers;

use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\OrderDetail;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use Symfony\Component\HttpFoundation\RedirectResponse;

class OrderController extends Controller
{
    public function index(): View
    {
        $user = Auth::user();
        $orderItems = $user->shoppingCarts->last()->shoppingCartItems;

        $userLocation = $user->userAddresses()->where('is_default', true)->first();
        $defaultAddress = $userLocation ? $userLocation->address : null;

        $totalPrice = $orderItems->sum(function ($item) {
            return $item->product()->price * $item->qty;
        });

        return view('components.orders.index', compact('user', 'orderItems', 'defaultAddress', 'totalPrice'));
    }

    public function store(Request $request): RedirectResponse
    {
        $orderDetail = null;

        DB::transaction(function () use ($request, &$orderDetail) {
            // dd(request()->all());
            $orderStatus = OrderStatus::create([
                'status' => 'Pending',
            ]);

            $orderDetail = OrderDetail::create([
                'user_id' => $request->user_id,
                'address_id' => $request->address_id,
                'order_date' => $request->order_date,
                'order_total' => $request->order_total,
                'order_status_id' => $orderStatus->id,
            ]);

            foreach ($request->order_items as $item) {
                OrderItem::create([
                    'order_detail_id' => $orderDetail->id,
                    'product_id' => $item['product_id'],
                    'qty' => $item['qty'],
                    'price' => $item['price'],
                ]);
            }
        });

        return redirect()->route('orders.confirmation', ['order_id' => $orderDetail->id]);
    }

    public function showConfirmation($order_id): View
    {
        $orderDetail = OrderDetail::with(['user', 'address'])->findOrFail($order_id);

        return view('components.orders.confirmation', [
            'orderDetail' => $orderDetail,
            'user' => $orderDetail->user,
            'address' => $orderDetail->address,
        ]);
    }
}
