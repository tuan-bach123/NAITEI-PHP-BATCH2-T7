function sidebarOpen() {
    document.getElementsByClassName('cart__sidebar')[0].classList.add('show');
    document.getElementsByClassName('cart__sidecontainer')[0].classList.add('show');
}

function sidebarClose() {
    document.getElementsByClassName('cart__sidebar')[0].classList.remove('show');
    document.getElementsByClassName('cart__sidecontainer')[0].classList.remove('show');
}
