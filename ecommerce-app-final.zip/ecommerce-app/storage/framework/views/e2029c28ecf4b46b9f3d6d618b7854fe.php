<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((
    ['product']
));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((
    ['product']
), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white p-4 rounded-lg shadow">
    <a href="<?php echo e(route('products.show', ['product' => $product->id])); ?>">
        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover rounded">
    </a>
    <h3 class="mt-4 text-lg font-semibold">
        <a href="<?php echo e(route('products.show', ['product' => $product->id])); ?>"><?php echo e($product->name); ?></a>
    </h3>
    <p class="text-gray-500"><?php echo e($product->description); ?></p>
    <p class="text-gray-600 mt-2">Category: <?php echo e($product->category?->name); ?></p>
    <p class="text-gray-800 font-bold mt-2">$<?php echo e(number_format($product->price, 2)); ?></p>
    <div class="mt-2 flex items-center">
        <!-- Display stars for the product -->
        <?php for($i = 0; $i < floor($product->rating); $i++): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="21.87" height="20.801" class="text-yellow-400 fill-current">
                <path
                    d="m4.178 20.801 6.758-4.91 6.756 4.91-2.58-7.946 6.758-4.91h-8.352L10.936 0 8.354 7.945H0l6.758 4.91-2.58 7.946z" />
            </svg>
        <?php endfor; ?>
        <?php for($i = $product->rating; $i < 5; $i++): ?>
            <svg xmlns="http://www.w3.org/2000/svg" width="21.87" height="20.801" class="text-gray-300 fill-current">
                <path
                    d="m4.178 20.801 6.758-4.91 6.756 4.91-2.58-7.946 6.758-4.91h-8.352L10.936 0 8.354 7.945H0l6.758 4.91-2.58 7.946z" />
            </svg>
        <?php endfor; ?>
        <span class="ml-2 text-gray-600"><?php echo e($product->rating); ?></span>
        <span class="ml-2 text-gray-600">(<?php echo e($product->user_reviews_count); ?> reviews)</span>
    </div>
</div>



<?php /**PATH C:\Users\ADMIN\Downloads\Laravel_Project1\NAITEI-PHP-BATCH2-T7\ecommerce-app\resources\views/components/product.blade.php ENDPATH**/ ?>