<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">
    <!-- Navigation Bar -->
    <?php echo $__env->make('components.admin.navbar-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <div class="sm:ml-64">
            <div class="mt-14 bg-white dark:border-gray-700">
                <?php echo e($slot); ?>

            </div>
        </div>

    </main>


    <script></script>
</body>

</html>
<?php /**PATH C:\Users\ADMIN\Downloads\Laravel_Project1\NAITEI-PHP-BATCH2-T7\ecommerce-app\resources\views/components/admin/layout.blade.php ENDPATH**/ ?>